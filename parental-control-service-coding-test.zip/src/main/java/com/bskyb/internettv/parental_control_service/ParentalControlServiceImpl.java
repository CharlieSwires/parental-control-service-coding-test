package com.bskyb.internettv.parental_control_service;

import com.bskyb.internettv.thirdparty.MovieService;
import com.bskyb.internettv.thirdparty.MovieServiceImpl;

public class ParentalControlServiceImpl implements ParentalControlService {

    public boolean canWatchMovie(String customerParentalControlLevel, String movieId)
            throws Exception {
        ParentalControlEnum watcher = ParentalControlEnum.valueOfLabel(customerParentalControlLevel);
        MovieService ms = new MovieServiceImpl();
        ParentalControlEnum movie = ParentalControlEnum.valueOfLabel(ms.getParentalControlLevel(movieId));

        return ParentalControlEnum.allowAccess(movie, watcher);
    }

}
