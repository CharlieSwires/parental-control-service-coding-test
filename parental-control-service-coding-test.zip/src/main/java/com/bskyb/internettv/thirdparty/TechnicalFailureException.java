package com.bskyb.internettv.thirdparty;

public class TechnicalFailureException extends Exception {
}
